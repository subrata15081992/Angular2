import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
			<h1>Wait</h1>
			`
})
export class AppComponent { }
